# generated from genmsg/cmake/pkg-msg-paths.cmake.develspace.in

set(velodyne_msgs_MSG_INCLUDE_DIRS "/home/sanjita/catkin_ws/src/velodyne/velodyne_msgs/msg")
set(velodyne_msgs_MSG_DEPENDENCIES std_msgs)
